class NarrowdownListener < Redmine::Hook::ViewListener
  def view_issues_edit_notes_bottom(*args)
    js = <<~'JS'
      (function($) {
        function setupAssignNarrowdown() {
          var $select = $('#issue_assigned_to_id');

          if (!$select.length) {
            return;
          }

          if ($select.data('assign-narrowdown-installed')) {
            return;
          }
          $select.data('assign-narrowdown-installed', true);

          var userIdList = {};

          $('a[href*="/users/"]').each(function() {
            var href = $(this).attr('href') || '';
            var match = href.match(/\/users\/(\d+)(?:$|[?#\/])/);

            if (match) {
              userIdList[match[1]] = true;
            }
          });

          var $checkbox = $('<input type="checkbox">')
            .attr('id', 'assign_narrowdown_checkbox');

          var $label = $('<label>')
            .attr('for', 'assign_narrowdown_checkbox')
            .text('関係者のみ')
            .css({
              'display': 'inline-block',
              'font-size': '80%',
              'cursor': 'pointer',
              'margin-left': '4px'
            });

          $select.after($checkbox);
          $checkbox.after($label);

          $checkbox.on('change', function() {
            var checked = $(this).prop('checked');

            $select.find('option').each(function() {
              var value = $(this).val();

              if (!value || !checked || userIdList[value]) {
                $(this).show();
              } else {
                $(this).hide();
              }
            });
          });
        }

        $(setupAssignNarrowdown);
      })(jQuery);
    JS

    "<script>//<![CDATA[\n#{js}\n//]]></script>"
  end
end
